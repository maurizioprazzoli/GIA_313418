-- Input
-- 	Produttore	  'PR1'
DELETE FROM [Producer]
      WHERE [Code] = 'PR1'