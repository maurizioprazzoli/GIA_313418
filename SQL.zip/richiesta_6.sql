-- Input
-- 	SiteName	'website4.it'
-- 	InternalName	'WEBSITE4'
INSERT INTO [Website]
           ([ID]
		   ,[SiteName]
           ,[SiteAlias])
     VALUES
           (4
		   ,'website4.it'
           ,'WEBSITE4')